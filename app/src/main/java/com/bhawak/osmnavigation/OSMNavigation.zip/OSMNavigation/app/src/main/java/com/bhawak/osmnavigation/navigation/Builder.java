package com.bhawak.osmnavigation.navigation;

import androidx.annotation.Nullable;

import com.mapbox.services.android.navigation.v5.navigation.MapboxNavigationOptions;
import com.mapbox.services.android.navigation.v5.navigation.notification.NavigationNotification;

public class Builder extends MapboxNavigationOptions {
    @Override
    public boolean defaultMilestonesEnabled() {
        return false;
    }

    @Override
    public boolean enableFasterRouteDetection() {
        return false;
    }

    @Override
    public boolean enableAutoIncrementLegIndex() {
        return false;
    }

    @Override
    public boolean enableRefreshRoute() {
        return false;
    }

    @Override
    public long refreshIntervalInMilliseconds() {
        return 0;
    }

    @Override
    public boolean isFromNavigationUi() {
        return false;
    }

    @Override
    public boolean isDebugLoggingEnabled() {
        return false;
    }

    @Nullable
    @Override
    public NavigationNotification navigationNotification() {
        return null;
    }

    @Override
    public int roundingIncrement() {
        return 0;
    }

    @Override
    public int timeFormatType() {
        return 0;
    }

    @Override
    public int navigationLocationEngineIntervalLagInMilliseconds() {
        return 0;
    }

    @Override
    public int defaultNotificationColorId() {
        return 0;
    }

    @Override
    public float offRouteThreshold() {
        return 0;
    }

    @Override
    public float offRouteThresholdWhenNearIntersection() {
        return 0;
    }

    @Override
    public float intersectionRadiusForOffRouteDetection() {
        return 0;
    }

    @Override
    public Builder toBuilder() {
        return null;
    }
}
