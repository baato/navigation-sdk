/**
 * Contains navigation milestone classes for receiving information when the user reaches a defined
 * point along the route.
 */
package com.mapbox.services.android.navigation.v5.milestone;