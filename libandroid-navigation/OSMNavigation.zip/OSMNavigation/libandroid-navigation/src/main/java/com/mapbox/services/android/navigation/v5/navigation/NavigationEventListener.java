package com.mapbox.services.android.navigation.v5.navigation;

public interface NavigationEventListener {
  void onRunning(boolean running);
}
