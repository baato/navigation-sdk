/**
 * Contains classes which define the UI components of the Navigation UI SDK
 *
 * @since 0.4.0
 */
package com.mapbox.services.android.navigation.ui.v5;