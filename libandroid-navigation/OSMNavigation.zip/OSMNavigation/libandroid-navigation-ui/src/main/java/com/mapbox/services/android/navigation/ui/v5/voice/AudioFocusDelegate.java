package com.mapbox.services.android.navigation.ui.v5.voice;

interface AudioFocusDelegate {

  void requestFocus();

  void abandonFocus();
}
